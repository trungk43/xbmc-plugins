﻿import os, xbmc

xbmc.executebuiltin("RunAddon(plugin.video.hdplay)")